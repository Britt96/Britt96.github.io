"use strict";
/*
  Assignment: Chapter 5 BMI Tracker App
  Author: Brittny Eaddy
  Date: 8/20/2020
  Purpose: To provide the functionality to preload information in the
    User Info and Records pages.
*/